package models;

/**
 *
 * 
 * 
 */
public interface IObserver {

    /**
     *
     */
    public void observerUpdate();
}
